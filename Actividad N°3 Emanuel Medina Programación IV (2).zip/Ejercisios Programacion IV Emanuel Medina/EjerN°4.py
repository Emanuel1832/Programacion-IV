def contar_las_vocales(palabra):
    vocales = "aeiou"
    contador = 0
    for letra in palabra:
        if letra in vocales:
            contador += 1
    return contador

def contar_las_consonantes(palabra):
    consonantes = "bcdfghjklmnñpqrstvwxyzBCDFGHJKLMNÑPQRSTVWXYZ"
    contador = 0
    for letra in palabra:
        if letra in consonantes:
            contador += 1
    return contador

texto = input("Ingrese una oracion:")

palabras = texto.split()

total_vocales = 0
total_consonantes = 0

for palabra in palabras:
    total_vocales += contar_las_vocales(palabra)
    total_consonantes += contar_las_consonantes(palabra)

print(f"\nTotal de vocales en el texto: {total_vocales}")
print(f"Total de consonantes en el texto: {total_consonantes}")
