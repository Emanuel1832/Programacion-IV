def carga_de_vector(n):
    vector = []
    for i in range(n):
        num = int(input(f"Ingrese el número {i+1} del vector: "))
        vector.append(num)
    return vector

def sumar_elementos(vector):
    return sum(vector)

def sumar_vectores(A, B):
    resultado = []
    for i in range(len(A)):
        resultado.append(A[i] + B[i])
    return resultado

N = int(input("Ingrese la cantidad de numeros para el vector A: "))
M = int(input("Ingrese la cantidad de numeros para el vector B: "))

print("Numeros del vector A")
vector_A = carga_de_vector(N)

print("Numeros del vector B")
vector_B = carga_de_vector(M)

suma_A = sumar_elementos(vector_A)
suma_B = sumar_elementos(vector_B)

print(f"Suma de los numeros del vector A: {suma_A}")
print(f"Suma de los numeros del vector B: {suma_B}")

if N == M:
    vector_resultante = sumar_vectores(vector_A, vector_B)
    print(f"La suma de los vectores A y B es: {vector_resultante}")