def maximo_de_tres_numeros(Primer_Numero, Segundo_Numero, Tercer_Numero):

    if Primer_Numero >= Segundo_Numero and Tercer_Numero >= Tercer_Numero:
        return Primer_Numero
    elif Segundo_Numero >= Primer_Numero and Segundo_Numero >= Tercer_Numero:
        return Segundo_Numero
    else:
        return Tercer_Numero
    
n1 = float(input("Ingrese el primer número: "))
n2 = float(input("Ingrese el segundo número: "))
n3 = float(input("Ingrese el tercer número: "))

print("El número máximo es:", maximo_de_tres_numeros(n1, n2, n3))