def maximo_de_tres_numeros(Primer_Numero, Segundo_Numero, Tercer_Numero, Cuarto_Numero, Quinto_Numero, Sexto_Numero, Septimo_Numero, Octavo_Numero, Noveno_Numero, Decimo_Numero):

    if (Primer_Numero >= Segundo_Numero and Primer_Numero >= Tercer_Numero and Primer_Numero >= Cuarto_Numero and 
        Primer_Numero >= Quinto_Numero and Primer_Numero >= Sexto_Numero and Primer_Numero >= Septimo_Numero and 
        Primer_Numero >= Octavo_Numero and Primer_Numero >= Noveno_Numero and Primer_Numero >= Decimo_Numero):
        return Primer_Numero
    
    elif (Segundo_Numero >= Tercer_Numero and Segundo_Numero >= Cuarto_Numero and Segundo_Numero >= Quinto_Numero and 
          Segundo_Numero >= Sexto_Numero and Segundo_Numero >= Septimo_Numero and Segundo_Numero >= Octavo_Numero and 
          Segundo_Numero >= Noveno_Numero and Segundo_Numero >= Decimo_Numero):
        return Segundo_Numero

    elif (Tercer_Numero >= Cuarto_Numero and Tercer_Numero >= Quinto_Numero and Tercer_Numero >= Sexto_Numero and 
          Tercer_Numero >= Septimo_Numero and Tercer_Numero >= Octavo_Numero and Tercer_Numero >= Noveno_Numero and 
          Tercer_Numero >= Decimo_Numero):
        return Tercer_Numero

    elif (Cuarto_Numero >= Quinto_Numero and Cuarto_Numero >= Sexto_Numero and Cuarto_Numero >= Septimo_Numero and 
          Cuarto_Numero >= Octavo_Numero and Cuarto_Numero >= Noveno_Numero and Cuarto_Numero >= Decimo_Numero):
        return Cuarto_Numero

    elif (Quinto_Numero >= Sexto_Numero and Quinto_Numero >= Septimo_Numero and Quinto_Numero >= Octavo_Numero and 
          Quinto_Numero >= Noveno_Numero and Quinto_Numero >= Decimo_Numero):
        return Quinto_Numero

    elif (Sexto_Numero >= Septimo_Numero and Sexto_Numero >= Octavo_Numero and Sexto_Numero >= Noveno_Numero and 
          Sexto_Numero >= Decimo_Numero):
        return Sexto_Numero

    elif (Septimo_Numero >= Octavo_Numero and Septimo_Numero >= Noveno_Numero and Septimo_Numero >= Decimo_Numero):
        return Septimo_Numero

    elif (Octavo_Numero >= Noveno_Numero and Octavo_Numero >= Decimo_Numero):
        return Octavo_Numero

    elif (Noveno_Numero >= Decimo_Numero):
        return Noveno_Numero
    
    else:
        return Decimo_Numero


n1 = float(input("Ingrese el primer número: "))
n2 = float(input("Ingrese el segundo número: "))
n3 = float(input("Ingrese el tercer número: "))
n4 = float(input("Ingrese el cuarto número: "))
n5 = float(input("Ingrese el quinto número: "))
n6 = float(input("Ingrese el sexto número: "))
n7 = float(input("Ingrese el séptimo número: "))
n8 = float(input("Ingrese el octavo número: "))
n9 = float(input("Ingrese el noveno número: "))
n10 = float(input("Ingrese el décimo número: "))

print("El número máximo es:", maximo_de_tres_numeros(n1, n2, n3, n4, n5, n6, n7, n8, n9, n10))